equistore-operations
====================

This package contains the Python *operations* to manipulate equistore data. Most
users will want to use the ``equistore`` package instead, which re-export all
the functions from this package.
