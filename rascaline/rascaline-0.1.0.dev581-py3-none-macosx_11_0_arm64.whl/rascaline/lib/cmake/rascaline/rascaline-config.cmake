
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was rascaline-config.in.cmake                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

cmake_minimum_required(VERSION 3.16)

if(rascaline_FOUND)
    return()
endif()

enable_language(CXX)

get_filename_component(RASCALINE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

if (WIN32)
    set(RASCALINE_SHARED_LOCATION ${RASCALINE_PREFIX_DIR}/bin/librascaline.dylib)
    set(RASCALINE_IMPLIB_LOCATION ${RASCALINE_PREFIX_DIR}/lib/librascaline.dylib.lib)
else()
    set(RASCALINE_SHARED_LOCATION ${RASCALINE_PREFIX_DIR}/lib/librascaline.dylib)
endif()

set(RASCALINE_STATIC_LOCATION ${RASCALINE_PREFIX_DIR}/lib/librascaline.a)
set(RASCALINE_INCLUDE ${RASCALINE_PREFIX_DIR}/include/)

if (NOT EXISTS ${RASCALINE_INCLUDE}/rascaline.h OR NOT EXISTS ${RASCALINE_INCLUDE}/rascaline.hpp)
    message(FATAL_ERROR "could not find rascaline headers in '${RASCALINE_INCLUDE}', please re-install rascaline")
endif()

find_package(metatensor 0.1 REQUIRED CONFIG)

# Shared library target
if (OFF OR ON)
    if (NOT EXISTS ${RASCALINE_SHARED_LOCATION})
        message(FATAL_ERROR "could not find rascaline library at '${RASCALINE_SHARED_LOCATION}', please re-install rascaline")
    endif()

    add_library(rascaline::shared SHARED IMPORTED GLOBAL)
    set_target_properties(rascaline::shared PROPERTIES
        IMPORTED_LOCATION ${RASCALINE_SHARED_LOCATION}
        INTERFACE_INCLUDE_DIRECTORIES ${RASCALINE_INCLUDE}
        IMPORTED_LINK_INTERFACE_LANGUAGES CXX
    )
    target_link_libraries(rascaline::shared INTERFACE metatensor::shared)

    target_compile_features(rascaline::shared INTERFACE cxx_std_17)

    if (WIN32)
        if (NOT EXISTS ${RASCALINE_IMPLIB_LOCATION})
            message(FATAL_ERROR "could not find rascaline library at '${RASCALINE_IMPLIB_LOCATION}', please re-install rascaline")
        endif()

        set_target_properties(rascaline::shared PROPERTIES
            IMPORTED_IMPLIB ${RASCALINE_IMPLIB_LOCATION}
        )
    endif()
endif()


# Static library target
if (OFF OR NOT ON)
    if (NOT EXISTS ${RASCALINE_STATIC_LOCATION})
        message(FATAL_ERROR "could not find rascaline library at '${RASCALINE_STATIC_LOCATION}', please re-install rascaline")
    endif()

    add_library(rascaline::static STATIC IMPORTED GLOBAL)
    set_target_properties(rascaline::static PROPERTIES
        IMPORTED_LOCATION ${RASCALINE_STATIC_LOCATION}
        INTERFACE_INCLUDE_DIRECTORIES ${RASCALINE_INCLUDE}
        INTERFACE_LINK_LIBRARIES "c;m"
        IMPORTED_LINK_INTERFACE_LANGUAGES CXX
    )
    target_link_libraries(rascaline::static INTERFACE metatensor::shared)

    target_compile_features(rascaline::static INTERFACE cxx_std_17)
endif()


# Export either the shared or static library as the rascaline target
if (ON)
    add_library(rascaline ALIAS rascaline::shared)
else()
    add_library(rascaline ALIAS rascaline::static)
endif()
