// empty lib.rs, this crate only exists to run Python tests with cargo
