equistore-core
==============

This package contains the Python bindings to the core C API of equistore. Most
users will want to use the ``equistore`` meta package instead, which also
includes function to operate on the data.
