import os


cmake_prefix_path = os.path.join(os.path.dirname(__file__), "lib", "cmake")
"""
Path containing the CMake configuration files for the underlying C library
"""
