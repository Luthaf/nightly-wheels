# placeholder test that is removed once the first test is add
import metatensor.learn


def test_dummpy():
    metatensor.learn
    pass
