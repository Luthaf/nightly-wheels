metatensor-learn
=====================

This package contains building blocks for the atomistic machine learning models based on PyTorch and NumPy.
